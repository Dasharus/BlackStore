﻿using System.Linq;
using BlackStore.Models;
using BlackStore.Models.ViewModels;

namespace BlackStore.Controllers
{
    internal class ProductListViewModel
    {
        public IQueryable<Product> Products { get; set; }
        public PagingInfo PagingInfo { get; set; }
        public string CurrentCategory { get; set; }
    }
}